import os

import matplotlib.pyplot as plt
import matplotlib.colors as colors
import numpy as np
import openmc.mgxs as mgxs

import openmc

#matplotlib inline

model = openmc.Model()

# Material definitions

# material 1 FUEL01
matuo2 = openmc.Material(name='uo2')
matuo2.add_nuclide('O16',  4.576420E-02)
matuo2.add_nuclide('U234',  6.118640E-06)
matuo2.add_nuclide('U235',  7.181320E-04)
matuo2.add_nuclide('U236',  3.298610E-06)
matuo2.add_nuclide('U238',  2.215460E-02)
matuo2.set_density('g/cm3', 10.25701)
matuo2.temperature=  600.000

# material 2 FUEL02
matgad = openmc.Material(name='gad')
matgad.add_nuclide('O16',  4.537050E-02)
matgad.add_nuclide('Gd152',  3.359600E-06)
matgad.add_nuclide('Gd154',  3.661900E-05)
matgad.add_nuclide('Gd155',  2.486060E-04)
matgad.add_nuclide('Gd156',  3.438490E-04)
matgad.add_nuclide('Gd157',  2.628840E-04)
matgad.add_nuclide('Gd158',  4.172550E-04)
matgad.add_nuclide('Gd160',  3.671980E-04)
matgad.add_nuclide('U234',  3.180960E-06)
matgad.add_nuclide('U235',  3.905000E-04)
matgad.add_nuclide('U236',  1.793000E-06)
matgad.add_nuclide('U238',  2.102990E-02)
matgad.set_density('g/cm3', 10.11099)
matgad.temperature=  600.000

#
matwater = openmc.Material(name='water')
matwater.add_nuclide('H1',  4.962240E-02)
matwater.add_nuclide('O16',  2.481120E-02)
matwater.add_nuclide('B10',  1.070700E-05)
matwater.add_nuclide('B11',  4.309710E-05)
matwater.set_density('g/cm3',  0.74300)
matwater.temperature=  600.000
matwater.add_s_alpha_beta('c_H_in_H2O')

model.materials = openmc.Materials([matuo2, matgad, matwater])

# Create the surface used for each pin
rodlen = 0.479
x = 0
y = 0
bndw1 = openmc.XPlane( x0 = x-rodlen, surface_id = 101)
bnde1 = openmc.XPlane( x0 = x+rodlen, surface_id = 102)
bnds1 = openmc.YPlane( y0 = y-rodlen, surface_id = 103)
bndn1 = openmc.YPlane( y0 = y+rodlen, surface_id = 104)
regpin = +bndw1 & -bnde1 & +bnds1 & -bndn1
regcool = ~(+bndw1 & -bnde1 & +bnds1 & -bndn1)

# Create the cells which will be used to represent each pin type.
cells = {}
universes = {}
for material in model.materials:
    # Create the cell for the material inside the cladding
    cells[material.name] = openmc.Cell(name=material.name)
    # Assign the half-spaces to the cell
    cells[material.name].region = regpin
    # Register the material with this cell
    cells[material.name].fill = material
    
    # Repeat the above for the material outside the cladding (i.e., the moderator)
    cell_name = material.name + '_moderator'
    cells[cell_name] = openmc.Cell(name=cell_name)
    cells[cell_name].region = regcool
    cells[cell_name].fill = matwater
    
    # Finally add the two cells we just made to a Universe object
    universes[material.name] = openmc.Universe(name=material.name)
    universes[material.name].add_cells([cells[material.name], cells[cell_name]])
    
    
lattices = {}

# Instantiate the UO2 Lattice
lattices['UO2 Assembly'] = openmc.RectLattice(name='UO2 Assembly')
lattices['UO2 Assembly'].dimension = [17, 17]
lattices['UO2 Assembly'].lower_left = [-10.71, -10.71]
lattices['UO2 Assembly'].pitch = [1.26, 1.26]
u = universes['uo2']
w = universes['water']
lattices['UO2 Assembly'].universes = \
    [[u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, w, u, u, w, u, u, w, u, u, u, u, u],
     [u, u, u, w, u, u, u, u, u, u, u, u, u, w, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, w, u, u, w, u, u, w, u, u, w, u, u, w, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, w, u, u, w, u, u, w, u, u, w, u, u, w, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, w, u, u, w, u, u, w, u, u, w, u, u, w, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, w, u, u, u, u, u, u, u, u, u, w, u, u, u],
     [u, u, u, u, u, w, u, u, w, u, u, w, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u]]
    
# Create a containing cell and universe
cells['UO2 Assembly'] = openmc.Cell(name='UO2 Assembly')
cells['UO2 Assembly'].fill = lattices['UO2 Assembly']
universes['UO2 Assembly'] = openmc.Universe(name='UO2 Assembly')
universes['UO2 Assembly'].add_cell(cells['UO2 Assembly'])

# Instantiate the MOX Lattice
lattices['GAD Assembly'] = openmc.RectLattice(name='GAD Assembly')
lattices['GAD Assembly'].dimension = [17, 17]
lattices['GAD Assembly'].lower_left = [-10.71, -10.71]
lattices['GAD Assembly'].pitch = [1.26, 1.26]
g = universes['gad']
lattices['GAD Assembly'].universes = \
    [[u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, w, u, u, w, u, u, w, u, u, u, u, u],
     [u, u, u, w, u, g, u, u, u, u, u, g, u, w, u, u, u],
     [u, u, u, u, u, u, u, u, g, u, u, u, u, u, u, u, u],
     [u, u, w, g, u, w, u, u, w, u, u, w, u, g, w, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, g, u, g, u, u, u, u, u, u, u],
     [u, u, w, u, g, w, u, u, w, u, u, w, g, u, w, u, u],
     [u, u, u, u, u, u, u, g, u, g, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, w, g, u, w, u, u, w, u, u, w, u, g, w, u, u],
     [u, u, u, u, u, u, u, u, g, u, u, u, u, u, u, u, u],
     [u, u, u, w, u, g, u, u, u, u, u, g, u, w, u, u, u],
     [u, u, u, u, u, w, u, u, w, u, u, w, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u],
     [u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u, u]]
# Create a containing cell and universe
cells['GAD Assembly'] = openmc.Cell(name='GAD Assembly')
cells['GAD Assembly'].fill = lattices['GAD Assembly']
universes['GAD Assembly'] = openmc.Universe(name='GAD Assembly')
universes['GAD Assembly'].add_cell(cells['GAD Assembly'])
    
lattices['Core'] = openmc.RectLattice(name='2x2 core lattice')
lattices['Core'].dimension= [2, 2]
lattices['Core'].lower_left = [-21.42, -21.42]
lattices['Core'].pitch = [21.42, 21.42]

u = universes['UO2 Assembly']
m = universes['GAD Assembly']
lattices['Core'].universes = [[u, m],
                              [m, u]]


# Create boundary planes to surround the geometry
min_x = openmc.XPlane(x0=-21.42, boundary_type='vacuum')
max_x = openmc.XPlane(x0=+21.42, boundary_type='vacuum')
min_y = openmc.YPlane(y0=-21.42, boundary_type='vacuum')
max_y = openmc.YPlane(y0=+21.42, boundary_type='vacuum')

# Create root Cell
root_cell = openmc.Cell(name='root cell')
root_cell.fill = lattices['Core']

# Add boundary planes
root_cell.region = +min_x & -max_x & +min_y & -max_y

# Create root Universe
root_universe = openmc.Universe(name='root universe', universe_id=1000)
root_universe.add_cell(root_cell)

root_universe.plot(origin=(0., 0., 0.), width=(2* 21.42, 2 * 21.42), pixels=(1285, 1285),
                   color_by='material')
                   
# Create Geometry and set root Universe
geometry = openmc.Geometry(root_universe)

# Export to "geometry.xml"
model.geometry = geometry
model.export_to_xml()

# OpenMC simulation parameters
# Create an initial uniform spatial source distribution over fissionable zones
bounds = [-21.42, -21.42, -1e50, 21.42, 21.42, 1e50]
uniform_dist = openmc.stats.Box(bounds[:3], bounds[3:])

settings = openmc.Settings()
settings.source = openmc.source.IndependentSource(space=uniform_dist, constraints={'fissionable': True})
settings.batches = 1000
settings.inactive = 100
settings.particles = 200000
settings.output = {'tallies': True}

model.settings = settings

#==================== Set up cross sections =======================

# Instantiate a "coarse" 2-group EnergyGroups object
coarse_groups = mgxs.EnergyGroups([0., 0.625, 20.0e6])

# Instantiate a "fine" 8-group EnergyGroups object
fine_groups = mgxs.EnergyGroups([0., 0.058, 0.14, 0.28,
                                 0.625, 4.0, 5.53e3, 821.0e3, 20.0e6])

# Initialize a 2-group MGXS Library for OpenMOC
mgxs_lib = openmc.mgxs.Library(model.geometry)
mgxs_lib.energy_groups = fine_groups

# Types of cross sections available:
#   TotalXS ("total")
#   TransportXS ("transport" or "nu-transport with nu set to True)
#   AbsorptionXS ("absorption")
#   CaptureXS ("capture")
#   FissionXS ("fission" or "nu-fission" with nu set to True)
#   KappaFissionXS ("kappa-fission")
#   ScatterXS ("scatter" or "nu-scatter" with nu set to True)
#   ScatterMatrixXS ("scatter matrix" or "nu-scatter matrix" with nu set to True)
#   Chi ("chi")
#   ChiPrompt ("chi prompt")
#   InverseVelocity ("inverse-velocity")
#   PromptNuFissionXS ("prompt-nu-fission")
#   DelayedNuFissionXS ("delayed-nu-fission")
#   ChiDelayed ("chi-delayed")
#   Beta ("beta")

# Specify multi-group cross section types to compute
mgxs_lib.mgxs_types = ['transport', 'total', 'capture', 'absorption', 'nu-fission', 'fission', 'kappa-fission', 'scatter matrix', 'chi']

# Specify a "cell" domain type for the cross section tally filters
mgxs_lib.domain_type = 'material'

# Specify the cell domains over which to compute multi-group cross sections
# **** Note: users need to manually modify this list of cells they want edited
# **** Note: or call all cells
# mgxs_lib.domains = model.geometry.get_all_material_cells().values()
mgxs_lib.domains = [matuo2, matgad, matwater]

for material in mgxs_lib.domains:
    print ("generate cross sections for material", material.id , material.name)

# Compute cross sections on a nuclide-by-nuclide basis  (not used here)
## mgxs_lib.by_nuclide = True

# Construct all tallies needed for the multi-group cross section library
mgxs_lib.build_library()

# Create a "tallies.xml" file for the MGXS Library  - "merge" to reduce number of tallies
tallies = openmc.Tallies()
mgxs_lib.add_to_tallies_file(tallies) # , merge=True)


# Instantiate a tally Mesh
mesh = openmc.RegularMesh()
mesh.type = 'regular'
mesh.dimension = [17 * 2, 17 * 2]
mesh.lower_left = [-21.42, -21.42]
mesh.upper_right = [+21.42, +21.42]

# Instantiate tally Filter
mesh_filter = openmc.MeshFilter(mesh)

# Instantiate the Tally
tally = openmc.Tally(name='mesh tally')
tally.filters = [mesh_filter]
tally.scores = ['fission', 'flux']

# Add tally to collection
tallies.append(tally)

# Export all tallies to a "tallies.xml" file


model.tallies = tallies

#======================= Run ==========================

statepoint_file = model.run()
# ====================== Tallies ======================

# Load the last statepoint file
sp = openmc.StatePoint(statepoint_file)

# Retrieve OpenMC's k-effective value (used for edit at the end)
openmc_keff = sp.keff.nominal_value

# Initialize MGXS Library with OpenMC statepoint data
mgxs_lib.load_from_statepoint(sp)

# Store the cross section data in an "mgxs/mgxs.h5" HDF5 binary file
print ("creating HDF cross section file")
mgxs_lib.build_hdf5_store(filename='mgxs.h5')   # , directory='mgxs')

# finished
print ("OpenMC keff ", openmc_keff)
print ("done")

# Load the last statepoint file and keff value
sp = openmc.StatePoint(statepoint_file)

# Get the OpenMC pin power tally data
mesh_tally = sp.get_tally(name='mesh tally')
fission_rates = mesh_tally.get_values(scores=['fission'])

# Reshape array to 2D for plotting
fission_rates.shape = mesh.dimension

# Normalize to the average pin power
fission_rates /= np.mean(fission_rates)

# Force zeros to be NaNs so their values are not included when matplotlib calculates
# the color scale
fission_rates[fission_rates == 0.] = np.nan

# Plot the pin powers and the fluxes
plt.figure()
plt.imshow(fission_rates, interpolation='none', cmap='jet', origin='lower')
plt.colorbar()
plt.title('Pin Powers')
plt.savefig('pinpower.png')
plt.close()

# Load the last statepoint file and keff value
sp = openmc.StatePoint(statepoint_file)

# Get the OpenMC pin power tally data
mesh_tally = sp.get_tally(name='mesh tally')
fission_rates = mesh_tally.get_values(scores=['flux'])

# Reshape array to 2D for plotting
fission_rates.shape = mesh.dimension

# Normalize to the average pin power
fission_rates /= np.mean(fission_rates)

# Force zeros to be NaNs so their values are not included when matplotlib calculates
# the color scale
fission_rates[fission_rates == 0.] = np.nan

# Plot the pin powers and the fluxes
plt.figure()
plt.imshow(fission_rates, interpolation='none', cmap='jet', origin='lower')
plt.colorbar()
plt.title('flux_dist')
plt.savefig('pin_flux.png')
