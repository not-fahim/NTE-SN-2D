#!/bin/bash

# update 2026-06-26

# Sample script for running OpenMC cases.
# 1. Set number of processors in multiple places:
#   a) in the "BSUB -n" parameter
#   b) in the ""span[ptile=8]" command to put all processes on the same machine
#   c) in the "OMP_NUM_THREAD" variable
# 2. Set runtime that you think you will need.  Maximum 48 hours.
#     The shorter the runtime, the faster the job will start 
# 3. You need to activate the conda environment BEFORE submitting the script
#    > conda activate /rsstu/users/s/sppalmta/verabwr/openmc-env
# 4. Submit the job using the command "bsub < run_script.sh"

# NOTE: if you get an error message about conda init, or matplotlib not found,
#    it is because you didn't activate the enviroment first!

# BSUB commands:
#   -J is the job name
#   -n is the number of processors
#   -W is walltime in minutes, or HH:MM

#BSUB -J mini3x3-cartesian 
#BSUB -o out.%J
#BSUB -e err.%J
#BSUB -n 32
#BSUB -R "span[ptile=12]"
#BSUB -W 2:00
#x BSUB -W 24:00
#x BSUB bqueues -l casl

# casl queue limited to 24 hours
# leave off the queue command to get standard queue, which allows 48 hours

# Note that if you have a long run time, it will put you in queue for a longer time,
# and may not run at all

#=======================================
date

### You need to activate conda before you submit the job!

#  edit the number of processors
export OMP_NUM_THREADS=32
echo "OMP_NUM_THREADS=$OMP_NUM_THREADS"
echo "OPENMC_CROSS_SECTIONS $OPENMC_CROSS_SECTIONS"
ls -Fl $OPENMC_CROSS_SECTIONS
# export OPENMC_CROSS_SECTIONS=/rsstu/users/s/sppalmta/verabwr/XSDATA/openmc-endfb-vii.1-hdf5/cross_sections.xml

#  edit the cpu info for later use (what computer did you run on?)
echo " "
echo "Echo CPU info"
lscpu

#  run case
python3 34x34-bare.py

echo "finished"
date

